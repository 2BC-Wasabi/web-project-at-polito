class ExamMarking{
    constructor(esid,sid,score,cid,slotID) {
        this.esid = esid;
        this.sid = sid;
        this.score = score;
        this.cid = cid;
        this.slotID = slotID
    }
}
export default ExamMarking;