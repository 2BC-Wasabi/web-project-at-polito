class ExamBooking{
    constructor(esid,sid,studentName,slotID,date,time) {
        this.esid = esid;
        this.sid = sid;
        this.name = studentName;
        this.slotID = slotID;
        this.date = date;
        this.time = time;

    }
}
export default ExamBooking;