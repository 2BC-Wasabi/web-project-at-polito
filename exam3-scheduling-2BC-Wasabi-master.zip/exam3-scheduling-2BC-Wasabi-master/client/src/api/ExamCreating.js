class ExamCreating{
    constructor(name,sduration,numofStudents,sdate,edate,cid,tid,sessions,students) {
        this.name = name;
        this.sduration = sduration;
        this.numofStudents = numofStudents;
        this.sdate = sdate;
        this.edate = edate;
        this.cid = cid;
        this.tid = tid;
        this.sessions = sessions;
        this.students = students;
    }
}
export default ExamCreating;