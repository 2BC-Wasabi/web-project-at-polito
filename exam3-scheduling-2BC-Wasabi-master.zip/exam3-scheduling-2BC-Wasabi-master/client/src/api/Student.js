class Student{
    constructor(sid,sname) {
        this.sid = sid;
        this.sname = sname;
    }
}
export default Student;