import React from 'react';

export const LoggedInUserContext = React.createContext({authUser: {}});
