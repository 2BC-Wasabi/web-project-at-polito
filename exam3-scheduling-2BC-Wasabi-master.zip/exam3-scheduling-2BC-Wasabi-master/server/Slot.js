class Slot{
    constructor(id,esid,sessionid,sid,name,sNumber,score) {
        this.id = id;
        this.esid = esid;
        this.sessionsid = sessionid;
        this.sid = sid;
        this.name = name;
        this.sNumber = sNumber;
        this.score = score;
    }
}
module.exports = Slot