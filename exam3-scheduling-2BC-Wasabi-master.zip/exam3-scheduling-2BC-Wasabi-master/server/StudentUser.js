class StudentUser{
    constructor(sid, name, mode) {
        this.sid = sid;
        this.name = name;
        this.mode = mode;
    }
}

module.exports = StudentUser;
