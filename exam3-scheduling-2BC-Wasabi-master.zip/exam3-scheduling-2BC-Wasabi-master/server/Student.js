class Student{
    constructor(sid,sname) {
        this.sid = sid;
        this.sname = sname;
    }
}
module.exports = Student;