class TeacherUser{
    constructor(username, mode,cid, hash) {

        this.username = username;
        this.mode = mode;
        this.cid = cid;
        this.hash = hash;
    }
}

module.exports = TeacherUser;
